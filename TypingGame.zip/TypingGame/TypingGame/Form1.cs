﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TypingGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            initial();
        }
        struct _PlayerData
        {
            public string Name, WinOrNot;
            public int Money;
        }
        struct _MultiBomb
        {
            public int[] character;
        }
        _MultiBomb[] MultiBomb = new _MultiBomb[4];
        _PlayerData[] PlayerData = new _PlayerData[50];
        _PlayerData[] ArrayTemp = new _PlayerData[50];
        Random rd;
        PictureBox[] Warrier = new PictureBox[WarrierMaximum];
        PictureBox[] Enemies = new PictureBox[WarrierMaximum];
        PictureBox[] ScrollChar = new PictureBox[4];
        ProgressBar[] WarrierHP = new ProgressBar[WarrierMaximum];
        ProgressBar[] EnemiesHP = new ProgressBar[WarrierMaximum];
        ProgressBar[] CastleHP = new ProgressBar[2];
        FileInfo fileinfo = new FileInfo("Rating.txt");
        StreamWriter streamwriter;
        StreamReader streamreader;

        static int WarrierMaximum = 10;
        int StartCount = 0,
            TagsMove = 3,
            Buffer = 0,
            BeginingBuffer = 0,
            Money = 2000,
            EnemiesMoney = 0,
            WarrierCurrent = 0,
            EnemiesCurrent = 0,
            WarrierHealth = 100,
            BuildCount = 0,
            Magnification = 1,
            CastleHealth = 4000,
            ECastleHealth = 4000,
            Player = 0,
            RateMaximum = 0,
            xPos, yPos;
        bool Tags1Activated,
            Tags2Activated,
            Tags3Activated,
            Tags4Activated,
            MIMoveDirect,
            MoveFlag,
            MoveFlagA,
            WinOrNot,
            KeyStart = false,
            Begin = false,
            BeginReverse = false,
            BeginMove = false,
            GeneratedOrNot = false,
            GameStart = false,
            groupbox = true,
            Stop = false;
        bool[] BuildRoom = new bool[3] { false, false, false };
        bool[] Archer = new bool[3] { false, false, false };
        bool[] Canon = new bool[3] { false, false, false };


        private void One20Sec_Tick(object sender, EventArgs e)
        {
            if (GeneratedOrNot)
            {
                for (int i = 0; i < MultiBomb.Length; i++)
                {
                    ScrollChar[i].Top += 5;
                    if (ScrollChar[i].Bottom > groupBox1.Bottom - 30)
                    {
                        MultiBomb[i].character[2] = 1;
                        Generated();
                    }
                }
            }
            if (KeyStart)
            {
                if (splitter1.Width < 180)
                    splitter1.Width += 3;
                else
                {
                    GameStart = true;
                    if (groupbox)
                    {
                        for (int i = 0; i < MultiBomb.Length; i++)
                            groupBox1.Controls.Add(ScrollChar[i]);
                        groupBox1.Visible = true;
                        label2.Visible = true;

                        LeftCannon2.Image = Image.FromFile("Cannon.png");
                        LeftCannon2.BackColor = Color.Transparent;
                        LeftCannon3.Image = Image.FromFile("Cannon.png");
                        LeftCannon3.BackColor = Color.Transparent;
                        LeftCannon4.Image = Image.FromFile("Cannon.png");
                        LeftCannon4.BackColor = Color.Transparent;
                        LeftArchorTower1.Image = Image.FromFile("ArchorTower.png");
                        LeftArchorTower1.BackColor = Color.Transparent;
                        LeftArchorTower2.Image = Image.FromFile("ArchorTower.png");
                        LeftArchorTower2.BackColor = Color.Transparent;
                        LeftArchorTower3.Image = Image.FromFile("ArchorTower.png");
                        LeftArchorTower3.BackColor = Color.Transparent;
                        pictureBox5.BackColor = Color.Transparent;
                        pictureBox6.BackColor = Color.Transparent;
                        pictureBox7.BackColor = Color.Transparent;
                        MainIndex.Controls.Add(LeftCannon2);
                        MainIndex.Controls.Add(LeftCannon3);
                        MainIndex.Controls.Add(LeftCannon4);
                        MainIndex.Controls.Add(LeftArchorTower1);
                        MainIndex.Controls.Add(LeftArchorTower2);
                        MainIndex.Controls.Add(LeftArchorTower3);
                        LeftCannon2.Location = new Point(1500, 0);
                        LeftCannon3.Location = new Point(1500, 0);
                        LeftCannon4.Location = new Point(1500, 0);
                        LeftArchorTower1.Location = new Point(1500, 0);
                        LeftArchorTower2.Location = new Point(1500, 0);
                        LeftArchorTower3.Location = new Point(1500, 0);
                        MainIndex.Controls.Add(pictureBox5);
                        pictureBox5.Location = new Point(140, 310);
                        MainIndex.Controls.Add(pictureBox6);
                        pictureBox6.Location = new Point(120, 240);
                        MainIndex.Controls.Add(pictureBox7);
                        pictureBox7.Location = new Point(80, 135);
                        DoubleMoney.Image = Image.FromFile("DoubleMoney.png");
                        DoubleMoney.BackColor = Color.Transparent;

                        CastleHP[0].Size = new Size(100, 15);
                        CastleHP[1].Size = new Size(100, 15);
                        MainIndex.Controls.Add(CastleHP[0]);
                        MainIndex.Controls.Add(CastleHP[1]);
                        CastleHP[0].Value = CastleHealth / 40;
                        CastleHP[1].Value = ECastleHealth / 40;
                        CastleHP[0].Location = new Point(50, 100);
                        CastleHP[1].Location = new Point(1050, 100);
                        pictureBox14.Visible = true;
                        pictureBox15.Visible = true;
                        One3Sec.Enabled = true;
                    }
                }

                if (pictureBox9.Top < this.Height || pictureBox11.Bottom > 0)
                {
                    pictureBox10.Top += 3;
                    pictureBox11.Top -= 3;
                }
                else
                    One20Sec.Enabled = false;
            }
            if (!Begin)
            {
                if (!BeginReverse)
                    BeginingBuffer++;
                else
                    BeginingBuffer--;
                if (BeginingBuffer <= 5)
                    pictureBox13.Image = Image.FromFile("ByMajjor" + BeginingBuffer + ".png");
                if (BeginingBuffer == 20)
                    BeginReverse = true;
                if (BeginingBuffer == 0)
                {
                    Begin = true;
                }
            }
            else
            {
                if (!BeginMove)
                {
                    if (pictureBox13.Right > 0)
                        pictureBox13.Left -= 8;
                    else
                    {
                        One20Sec.Enabled = false;
                        BeginMove = true;
                    }
                }
            }
        }

        private void OneSec_Tick(object sender, EventArgs e)
        {
            if (BuildCount > 0)
            {
                if (EnemiesHP[0].Value > 0)
                {
                    if (LeftCannon2.Right + 300 >= Enemies[0].Left && Canon[0])
                    {
                        if (EnemiesHP[0].Value >= 10)
                            EnemiesHP[0].Value -= 10;
                        else
                            EnemiesHP[0].Value -= EnemiesHP[0].Value;
                    }
                }
                if (EnemiesHP[0].Value > 0)
                {
                    if (LeftCannon3.Right + 300 >= Enemies[0].Left && Canon[1])
                    {
                        if (EnemiesHP[0].Value >= 10)
                            EnemiesHP[0].Value -= 10;
                        else
                            EnemiesHP[0].Value -= EnemiesHP[0].Value;
                    }
                }
                if (EnemiesHP[0].Value > 0)
                {
                    if (LeftCannon4.Right + 300 >= Enemies[0].Left && Canon[2])
                    {
                        if (EnemiesHP[0].Value >= 10)
                            EnemiesHP[0].Value -= 10;
                        else
                            EnemiesHP[0].Value -= EnemiesHP[0].Value;
                    }
                }
                if (EnemiesHP[0].Value > 0)
                {
                    if (LeftArchorTower1.Right + 500 >= Enemies[0].Left && Archer[0])
                    {
                        if (EnemiesHP[0].Value >= 5)
                            EnemiesHP[0].Value -= 5;
                        else
                            EnemiesHP[0].Value -= EnemiesHP[0].Value;
                    }
                }
                if (EnemiesHP[0].Value > 0)
                {
                    if (LeftArchorTower2.Right + 500 >= Enemies[0].Left && Archer[1])
                    {
                        if (EnemiesHP[0].Value >= 5)
                            EnemiesHP[0].Value -= 5;
                        else
                            EnemiesHP[0].Value -= EnemiesHP[0].Value;
                    }
                }
                if (EnemiesHP[0].Value > 0)
                {
                    if (LeftArchorTower3.Right + 500 >= Enemies[0].Left && Archer[2])
                    {
                        if (EnemiesHP[0].Value >= 5)
                            EnemiesHP[0].Value -= 5;
                        else
                            EnemiesHP[0].Value -= EnemiesHP[0].Value;
                    }
                }
            }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (BeginMove)
            {
                if (GeneratedOrNot)
                {
                    bool CorrectOrNot = false;
                    for (int i = 0; i < MultiBomb.Length; i++)
                    {
                        if ((Int32)e.KeyChar == MultiBomb[i].character[0])
                        {
                            MultiBomb[i].character[2] = 1;
                            CorrectOrNot = true;
                        }
                    }
                    if (CorrectOrNot)
                    {
                        Money += 5 * Magnification;
                        label2.Text = Money.ToString();
                        Generated();
                    }
                }


                void ChangeImage()
                {
                    StartCount++;
                    pictureBox8.Image = Image.FromFile("Start" + StartCount + ".png");
                }
                switch (StartCount)
                {
                    case 0:
                        {
                            if (!KeyStart && e.KeyChar == 83)
                            {
                                ChangeImage();
                            }
                            break;
                        }
                    case 1:
                        {
                            if (!KeyStart && e.KeyChar == 84)
                            {
                                ChangeImage();
                            }
                            break;
                        }
                    case 2:
                        {
                            if (!KeyStart && e.KeyChar == 65)
                            {
                                ChangeImage();
                            }
                            break;
                        }
                    case 3:
                        {
                            if (!KeyStart && e.KeyChar == 82)
                            {
                                ChangeImage();
                            }
                            break;
                        }
                    case 4:
                        {
                            if (!KeyStart && e.KeyChar == 84)
                            {
                                ChangeImage();
                                KeyStart = true;
                            }
                            break;
                        }
                }
                if (KeyStart)
                {
                    One20Sec.Enabled = true;
                    One2Sec.Enabled = true;
                }
            }
        }
        //=============================================================================

        void initial()
        {
            string str;
            if (File.Exists("Rating.txt"))
            {
                streamreader = new StreamReader("Rating.txt");
                str = streamreader.ReadLine();
                Player = int.Parse(str);
                if (Player > 4)
                {
                    RateMaximum = 4;
                }
                else
                    RateMaximum = Player;
                for (int j = 0; j < Player; j++)
                {
                    str = streamreader.ReadLine();
                    PlayerData[j].Name = str;
                    str = streamreader.ReadLine();
                    PlayerData[j].Money = int.Parse(str);
                    str = streamreader.ReadLine();
                    PlayerData[j].WinOrNot = str;
                }
                streamreader.Close();
            }
            rd = new Random();
            label2.Text = Money.ToString();
            CastleHP[0] = new System.Windows.Forms.ProgressBar();
            CastleHP[1] = new System.Windows.Forms.ProgressBar();
            for (int i = 0; i < MultiBomb.Length; i++)
            {
                MultiBomb[i].character = new int[5];
                MultiBomb[i].character[2] = 1;
                ScrollChar[i] = new System.Windows.Forms.PictureBox();
                ScrollChar[i].BackColor = Color.Transparent;
                ScrollChar[i].Size = new Size(40, 40);
                ScrollChar[i].SizeMode = PictureBoxSizeMode.StretchImage;
                ScrollChar[i].Image = Image.FromFile("Scroll.png");
            }
        }


        void Generated()
        {
            for (int i = 0; i < MultiBomb.Length; i++)
            {
                if (MultiBomb[i].character[2] == 1)
                {
                    Label LB = this.Controls.Find("L" + i.ToString(), true).FirstOrDefault() as Label;
                    MultiBomb[i].character[0] = rd.Next(33, 126);
                    LB.Text = ((char)MultiBomb[i].character[0]).ToString();
                    MultiBomb[i].character[1] = rd.Next(30, 100);
                    ScrollChar[i].Top = MultiBomb[i].character[1];
                    ScrollChar[i].Left = i * 33 + 5;
                    MultiBomb[i].character[2] = 0;
                    ScrollChar[i].Controls.Add(LB);
                    LB.Location = new Point(9, 10);
                }
            }
        }


        void TagSetting(string str)
        {
            groupBox1.Visible = false;
            Display1.Visible = true;
            Display1.Image = Image.FromFile(str);

            GeneratedOrNot = false;
            groupbox = false;
        }


        void TagContentSetting(int left1, int leftCannon)
        {
            Left1.Left = left1;
            LeftCannon.Left = leftCannon;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StartCount = 0;
            TagsMove = 3;
            Buffer = 0;
            BeginingBuffer = 0;
            Money = 0;
            EnemiesMoney = 0;
            WarrierCurrent = 0;
            EnemiesCurrent = 0;
            WarrierHealth = 100;
            BuildCount = 0;
            Magnification = 1;
            CastleHealth = 4000;
            ECastleHealth = 4000;
            KeyStart = false;
            Begin = false;
            BeginReverse = false;
            BeginMove = false;
            GeneratedOrNot = false;
            GameStart = false;
            groupbox = true;
            bool[] BuildRoom = new bool[3] { false, false, false };
            bool[] Archer = new bool[3] { false, false, false };
            bool[] Canon = new bool[3] { false, false, false };
            button1.Visible = false;
            button2.Visible = false;
            button2.Enabled = false;
            textBox2.Visible = false;
            textBox1.Visible = false;
            Money = 0;
            EnemiesMoney = 0;
            pictureBox8.Top = 90;
            pictureBox8.Left = 0;
            pictureBox9.Top = 0;
            pictureBox9.Left = 70;
            pictureBox11.Location = new Point(617, 273);
            pictureBox12.Top = 100;
            pictureBox13.Location = new Point(0, 0);
            for (int i = 0; i < WarrierMaximum; i++)
            {
                this.MainIndex.Controls.Remove(Warrier[i]);
                this.MainIndex.Controls.Remove(Enemies[i]);
                this.MainIndex.Controls.Remove(WarrierHP[i]);
                this.MainIndex.Controls.Remove(EnemiesHP[i]);
            }

        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            WinOrNot = false;
            GameOver();
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            if (!Stop && GameStart)
            {
                Stop = true;
                One2Sec.Enabled = false;
                One3Sec.Enabled = false;
                One20Sec.Enabled = false;
                OneSec.Enabled = false;
                pictureBox14.BackColor = Color.Red;
            }
            else if (Stop && GameStart)
            {
                Stop = false;
                One2Sec.Enabled = true;
                One3Sec.Enabled = true;
                One20Sec.Enabled = true;
                OneSec.Enabled = true;
                pictureBox14.BackColor = Color.Green;
            }

        }

        void GameOver()
        {
            OneSec.Enabled = false;
            One2Sec.Enabled = false;
            One3Sec.Enabled = false;
            One20Sec.Enabled = false;
            textBox1.Visible = true;
            button1.Visible = true;
            GameStart = false;
        }
        //=============================================================================

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Generated();
            if (GameStart)
            {
                groupBox1.Visible = true;
                Display1.Visible = false;
                GeneratedOrNot = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            button2.Enabled = true;
            button2.Visible = true;

            streamwriter = fileinfo.CreateText();

            PlayerData[Player].Name = textBox1.Text;
            PlayerData[Player].Money = Money;
            if (WinOrNot)
                PlayerData[Player].WinOrNot = "Win";
            else
                PlayerData[Player].WinOrNot = "Lose";
            Player++;
            streamwriter.WriteLine(Player);
            for (int i = 0; i < Player; i++)
            {
                for (int j = 0; j < Player; j++)
                {
                    if (PlayerData[i].Money > PlayerData[j].Money)
                    {
                        ArrayTemp[i] = PlayerData[i];
                        PlayerData[i] = PlayerData[j];
                        PlayerData[j] = ArrayTemp[i];
                    }
                }
            }
            textBox2.Text = "";
            for (int k = 0; k < Player; k++)
            {
                streamwriter.WriteLine(PlayerData[k].Name);
                streamwriter.WriteLine(PlayerData[k].Money);
                streamwriter.WriteLine(PlayerData[k].WinOrNot);
            }
            streamwriter.Flush();
            streamwriter.Close();
            if (RateMaximum < 5)
            {
                RateMaximum++;
                for (int f = 0; f < RateMaximum; f++)
                {
                    string str = string.Format("Number" + (f + 1).ToString() + "　Name:{0}\r\nMoney:{1} {2}\r\n", PlayerData[f].Name, PlayerData[f].Money, PlayerData[f].WinOrNot);
                    textBox2.AppendText(str);
                }
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

            TagSetting("Wall.png");
            Display1.Controls.Add(Left1);
            Left1.BackColor = Color.Transparent;
            Left1.Image = Image.FromFile("Warrier.png");
            DoubleMoney.Left = 1000;
            LeftArchorTower.Left = 1000;
            LeftCannon.Left = 1000;
            Left1.Top = 10;
            Left1.Left = 10;

        }

        private void LeftArchorTower_MouseUp(object sender, MouseEventArgs e)
        {
            MoveFlagA = false;
            if (LeftArchorTower1.Right >= pictureBox7.Left && LeftArchorTower1.Left <= pictureBox7.Right && LeftArchorTower1.Bottom >= pictureBox7.Top && LeftArchorTower1.Top <= pictureBox7.Bottom && !Archer[0] && !BuildRoom[0])
            {
                LeftArchorTower1.Location = new Point(pictureBox7.Location.X, pictureBox7.Location.Y);
                Archer[0] = true;
                BuildRoom[0] = true;
                Money -= 500;
                label2.Text = Money.ToString();
                BuildCount++;
            }
            else if (LeftArchorTower2.Right >= pictureBox5.Left && LeftArchorTower2.Left <= pictureBox5.Right && LeftArchorTower2.Bottom >= pictureBox5.Top && LeftArchorTower2.Top <= pictureBox5.Bottom && !Archer[1] && !BuildRoom[1])
            {
                LeftArchorTower2.Location = new Point(pictureBox5.Location.X, pictureBox5.Location.Y);
                Archer[1] = true;
                BuildRoom[1] = true;
                Money -= 500;
                label2.Text = Money.ToString();
                BuildCount++;
            }
            else if (LeftArchorTower3.Right >= pictureBox6.Left && LeftArchorTower3.Left <= pictureBox6.Right && LeftArchorTower3.Bottom >= pictureBox6.Top && LeftArchorTower3.Top <= pictureBox6.Bottom && !Archer[2] && !BuildRoom[2])
            {
                LeftArchorTower3.Location = new Point(pictureBox6.Location.X, pictureBox6.Location.Y);
                Archer[2] = true;
                BuildRoom[2] = true;
                Money -= 500;
                label2.Text = Money.ToString();
                BuildCount++;
            }
            if (!BuildRoom[0] && !Archer[0])
                LeftArchorTower1.Location = new Point(2000, 10);
            if (!BuildRoom[1] && !Archer[1])
                LeftArchorTower2.Location = new Point(2000, 10);
            if (!BuildRoom[2] && !Archer[2])
                LeftArchorTower3.Location = new Point(2000, 10);
            LeftArchorTower.Location = new Point(10, 150);
        }

        private void DoubleMoney_Click(object sender, EventArgs e)
        {
            if (Money >= 5000)
                Magnification += 10;
            Money -= 5000;
        }

        private void LeftArchorTower_MouseMove(object sender, MouseEventArgs e)
        {
            if (MoveFlagA)
            {
                LeftArchorTower.Left += Convert.ToInt16(e.X - xPos);//設定x座標.
                LeftArchorTower.Top += Convert.ToInt16(e.Y - yPos);//設定y座標.
                if (LeftArchorTower.Right >= Display1.Right)
                {
                    if (!BuildRoom[0] && !Archer[0])
                    {
                        LeftArchorTower1.Left = LeftArchorTower.Left - 50;
                        LeftArchorTower1.Top = LeftArchorTower.Top + 100;
                    }
                    if (!BuildRoom[1] && !Archer[1])
                    {
                        LeftArchorTower2.Location = new Point(LeftArchorTower.Location.X - 50, LeftArchorTower.Location.Y + 100);
                    }
                    if (!BuildRoom[2] && !Archer[2])
                    {
                        LeftArchorTower3.Location = new Point(LeftArchorTower.Location.X - 50, LeftArchorTower.Location.Y + 100);
                    }
                }
            }
        }

        private void LeftArchorTower_MouseDown(object sender, MouseEventArgs e)
        {
            if (Money >= 500)
            {
                MoveFlagA = true;
                xPos = e.X;
                yPos = e.Y;
            }
            else
            {

            }
        }

        private void LeftCannon_MouseDown(object sender, MouseEventArgs e)
        {
            if (Money >= 500)
            {
                MoveFlag = true;
                xPos = e.X;
                yPos = e.Y;
            }
            else
            {

            }
        }

        private void LeftCannon_MouseUp(object sender, MouseEventArgs e)
        {
            MoveFlag = false;
            if (LeftCannon2.Right >= pictureBox7.Left && LeftCannon2.Left <= pictureBox7.Right && LeftCannon2.Bottom >= pictureBox7.Top && LeftCannon2.Top <= pictureBox7.Bottom && !BuildRoom[0] && !Canon[0])
            {
                LeftCannon2.Location = new Point(pictureBox7.Location.X, pictureBox7.Location.Y);
                BuildRoom[0] = true;
                Canon[0] = true;
                BuildCount++;
                Money -= 500;
                label2.Text = Money.ToString();
            }
            else if (LeftCannon3.Right >= pictureBox5.Left && LeftCannon3.Left <= pictureBox5.Right && LeftCannon3.Bottom >= pictureBox5.Top && LeftCannon3.Top <= pictureBox5.Bottom && !BuildRoom[1] && !Canon[1])
            {
                LeftCannon3.Location = new Point(pictureBox5.Location.X, pictureBox5.Location.Y);
                BuildRoom[1] = true;
                Canon[1] = true;
                BuildCount++;
                Money -= 500;
                label2.Text = Money.ToString();
            }
            else if (LeftCannon4.Right >= pictureBox6.Left && LeftCannon4.Left <= pictureBox6.Right && LeftCannon4.Bottom >= pictureBox6.Top && LeftCannon4.Top <= pictureBox6.Bottom && !BuildRoom[2] && !Canon[2])
            {
                LeftCannon4.Location = new Point(pictureBox6.Location.X, pictureBox6.Location.Y);
                BuildRoom[2] = true;
                Canon[2] = true;
                BuildCount++;
                Money -= 500;
                label2.Text = Money.ToString();
            }
            if (!BuildRoom[0] && !Canon[0])
                LeftCannon2.Location = new Point(2000, 10);
            if (!BuildRoom[1] && !Canon[1])
                LeftCannon3.Location = new Point(2000, 10);
            if (!BuildRoom[2] && !Canon[2])
                LeftCannon4.Location = new Point(2000, 10);
            LeftCannon.Location = new Point(10, 10);


        }

        private void LeftCannon_MouseMove(object sender, MouseEventArgs e)
        {
            if (MoveFlag)
            {
                LeftCannon.Left += Convert.ToInt16(e.X - xPos);//設定x座標.
                LeftCannon.Top += Convert.ToInt16(e.Y - yPos);//設定y座標.
                if (LeftCannon.Right >= Display1.Right)
                {
                    if (!BuildRoom[0])
                    {
                        LeftCannon2.Left = LeftCannon.Left - 50;
                        LeftCannon2.Top = LeftCannon.Top + 100;
                    }
                    if (!BuildRoom[1])
                    {
                        LeftCannon3.Location = new Point(LeftCannon.Location.X - 50, LeftCannon.Location.Y + 100);
                    }
                    if (!BuildRoom[2])
                    {
                        LeftCannon4.Location = new Point(LeftCannon.Location.X - 50, LeftCannon.Location.Y + 100);
                    }
                }
            }
        }

        private void One2Sec_Tick(object sender, EventArgs e)
        {
            if (Buffer > 4)
            {
                pictureBox1.Image = Image.FromFile("MapleStoryMoneyBag.png");
                pictureBox2.Image = Image.FromFile("MinecraftPainting.png");
                pictureBox3.Image = Image.FromFile("DiamondSword.png");
                pictureBox4.Image = Image.FromFile("Brick.png");
                One2Sec.Enabled = false;
            }
            else
            {
                MainIndex.Image = Image.FromFile("BattleField" + Buffer + ".png");
            }
            Buffer++;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            TagSetting("Wall.png");
            Display1.Controls.Add(DoubleMoney);
            DoubleMoney.Location = new Point(10, 10);

            LeftCannon.Left = 1000;
            LeftArchorTower.Left = 1000;
            TagContentSetting(1000, 1000);

        }
        private void pictureBox4_Click(object sender, EventArgs e)
        {

            TagSetting("Wall.png");
            Display1.Controls.Add(LeftCannon);
            Display1.Controls.Add(LeftArchorTower);
            LeftCannon.BackColor = Color.Transparent;
            LeftCannon.Image = Image.FromFile("Cannon.png");
            LeftArchorTower.BackColor = Color.Transparent;
            LeftArchorTower.Image = Image.FromFile("ArchorTower.png");
            LeftCannon.Top = 10;
            LeftArchorTower.Top = 150;
            LeftArchorTower.Left = 10;
            TagContentSetting(1000, 10);
            DoubleMoney.Left = 1000;

        }


        private void Left1_Click(object sender, EventArgs e)
        {
            if (Money >= 50)
            {
                if (WarrierCurrent != WarrierMaximum)
                {
                    Warrier[WarrierCurrent] = new System.Windows.Forms.PictureBox();
                    Warrier[WarrierCurrent].BackColor = Color.Transparent;
                    Warrier[WarrierCurrent].Location = new Point(200, 180);
                    Warrier[WarrierCurrent].Size = new Size(120, 200);
                    Warrier[WarrierCurrent].SizeMode = PictureBoxSizeMode.StretchImage;
                    Warrier[WarrierCurrent].Image = Image.FromFile("Warrier.png");
                    MainIndex.Controls.Add(Warrier[WarrierCurrent]);
                    WarrierHP[WarrierCurrent] = new System.Windows.Forms.ProgressBar();
                    WarrierHP[WarrierCurrent].Value = WarrierHealth;
                    Warrier[WarrierCurrent].Controls.Add(WarrierHP[WarrierCurrent]);
                    WarrierHP[WarrierCurrent].Location = new Point(0, 0);
                    WarrierCurrent++;
                    Money -= 50;
                    label2.Text = Money.ToString();
                }
            }
        }

        private void One3Sec_Tick(object sender, EventArgs e)
        {
            bool WarrierMove = false,
                EnemiesMove = false,
                WarrierToWarrier = false,
                EnemiesToCastle = false,
                WarriertoCastle = false;
            int WarrierTemp = 0,
                EnemiesTemp = 0;
            EnemiesMoney += 2;

            if (EnemiesMoney >= 50)
            {
                if (EnemiesCurrent != WarrierMaximum)
                {
                    Enemies[EnemiesCurrent] = new System.Windows.Forms.PictureBox();
                    Enemies[EnemiesCurrent].BackColor = Color.Transparent;
                    MainIndex.Controls.Add(Enemies[EnemiesCurrent]);
                    Enemies[EnemiesCurrent].Location = new Point(900, 180);
                    Enemies[EnemiesCurrent].Size = new Size(120, 200);
                    Enemies[EnemiesCurrent].SizeMode = PictureBoxSizeMode.StretchImage;
                    Enemies[EnemiesCurrent].Image = Image.FromFile("EWarrier.png");
                    EnemiesHP[EnemiesCurrent] = new System.Windows.Forms.ProgressBar();
                    EnemiesHP[EnemiesCurrent].Value = WarrierHealth;
                    Enemies[EnemiesCurrent].Controls.Add(EnemiesHP[EnemiesCurrent]);
                    EnemiesHP[EnemiesCurrent].Location = new Point(0, 0);
                    EnemiesCurrent++;
                    EnemiesMoney -= 50;
                }
            }
            if (EnemiesCurrent > 0 && WarrierCurrent > 0 && Enemies[0].Left <= Warrier[0].Right)
                WarrierToWarrier = true;
            if (EnemiesCurrent > 0)
            {
                if (Enemies[0].Left <= 150)
                {
                    EnemiesToCastle = true;
                }
            }
            if (WarrierCurrent > 0)
            {
                if (Warrier[0].Left >= 800)
                {
                    WarriertoCastle = true;
                }
            }
            for (int j = 0; j < EnemiesCurrent; j++)
            {
                if (EnemiesMove)
                    break;
                if (EnemiesCurrent > 0)
                {
                    for (int x = j + 1; x < EnemiesCurrent; x++)
                    {
                        if (EnemiesMove)
                            break;
                        if (Enemies[j].Right > Enemies[x].Left)
                        {
                            EnemiesTemp = j;
                            EnemiesMove = true;
                        }
                    }
                }
            }
            for (int i = 0; i < WarrierCurrent; i++)
            {
                if (WarrierMove)
                    break;
                if (WarrierCurrent > 1)
                {
                    for (int y = i + 1; y < WarrierCurrent; y++)
                    {
                        if (WarrierMove)
                            break;
                        if (Warrier[i].Left <= Warrier[y].Right)
                        {
                            WarrierMove = true;
                            WarrierTemp = i;
                        }
                    }
                }
            }
            if (EnemiesMove && !WarrierToWarrier)
            {
                for (int b = 0; b <= EnemiesTemp; b++)
                    Enemies[b].Left -= 10;
            }
            else if (WarrierToWarrier)
            {
                for (int b = 1; b <= EnemiesTemp; b++)
                    Enemies[b].Left -= 10;
                if (WarrierHP[0].Value > 0 && EnemiesHP[0].Value > 0)
                {
                    if (WarrierHP[0].Value < 20)
                        WarrierHP[0].Value -= WarrierHP[0].Value;
                    else
                        WarrierHP[0].Value -= 20;
                    if (EnemiesHP[0].Value < 20)
                        EnemiesHP[0].Value -= EnemiesHP[0].Value;
                    else
                        EnemiesHP[0].Value -= 20;
                }
            }
            else if (EnemiesToCastle)
            {
                if (CastleHealth >= 400)
                    CastleHealth -= 400;
                else
                {
                    CastleHealth -= CastleHealth;
                    WinOrNot = false;
                    GameOver();
                }
                CastleHP[0].Value = CastleHealth / 40;
            }
            else
            {
                for (int k = 0; k < EnemiesCurrent; k++)
                    Enemies[k].Left -= 10;
            }
            if (WarrierMove && !WarrierToWarrier)
            {
                for (int a = 0; a <= WarrierTemp; a++)
                    Warrier[a].Left += 10;
            }
            else if (WarrierToWarrier)
            {

            }
            else if (WarriertoCastle)
            {
                if (ECastleHealth >= 400)
                    ECastleHealth -= 20;
                else
                {
                    ECastleHealth -= ECastleHealth;
                    WinOrNot = true;
                    GameOver();
                }
                CastleHP[1].Value = ECastleHealth / 40;

            }
            else
            {
                for (int h = 0; h < WarrierCurrent; h++)
                    Warrier[h].Left += 10;
            }

            if (WarrierCurrent > 0)
            {
                if (WarrierHP[0].Value == 0)
                {
                    this.MainIndex.Controls.Remove(Warrier[0]);
                    for (int d = 0; d < WarrierCurrent - 1; d++)
                    {
                        Warrier[d] = Warrier[d + 1];
                        WarrierHP[d] = WarrierHP[d + 1];
                    }
                    WarrierCurrent--;
                }
                if (Warrier[0].Right >= 800)
                {
                    ECastleHealth -= 20;
                    CastleHP[1].Value = ECastleHealth / 40;
                }
            }
            if (EnemiesCurrent > 0)
            {
                if (EnemiesHP[0].Value == 0)
                {
                    this.MainIndex.Controls.Remove(Enemies[0]);
                    for (int f = 0; f < EnemiesCurrent - 1; f++)
                    {
                        Enemies[f] = Enemies[f + 1];
                        EnemiesHP[f] = EnemiesHP[f + 1];
                    }
                    EnemiesCurrent--;
                }
            }
        }

        private void pictureBox12_MouseHover(object sender, EventArgs e)
        {
            if (KeyStart)
            {
                if (MousePosition.X >= splitter1.Right && MousePosition.X < splitter1.Right + 200)
                {
                    MIMoveDirect = false;
                    MainIndexMove1.Enabled = true;
                }
                else if (MousePosition.X <= this.Width + splitter1.Right && MousePosition.X >= this.Width + splitter1.Right - 200)
                {
                    MIMoveDirect = true;
                    MainIndexMove1.Enabled = true;
                }
                else
                    MainIndexMove1.Enabled = false;
            }
        }


        private void MainIndex_MouseLeave(object sender, EventArgs e)
        {
            MainIndexMove1.Enabled = false;
        }


        private void MainIndex_MouseMove(object sender, MouseEventArgs e)
        {
            if (KeyStart)
            {
                if (MousePosition.X >= splitter1.Right && MousePosition.X < splitter1.Right + 200)
                {
                    MIMoveDirect = false;
                    MainIndexMove1.Enabled = true;
                }
                else if (MousePosition.X <= this.Width + splitter1.Right && MousePosition.X >= this.Width + splitter1.Right - 200)
                {
                    MIMoveDirect = true;
                    MainIndexMove1.Enabled = true;
                }
                else
                    MainIndexMove1.Enabled = false;
            }
        }
        //--------------------------------------------------------------------
        private void MainIndexMove1_Tick(object sender, EventArgs e)
        {
            if (!MIMoveDirect)
            {
                if (MainIndex.Left < splitter1.Right)
                {
                    MainIndex.Left += 3;
                }
            }
            else
            {
                if (MainIndex.Right > ClientSize.Width)
                {
                    MainIndex.Left -= 3;
                }
            }
        }
        //--------------------------------------------------------------------
        private void TagsTimer1_Tick(object sender, EventArgs e)
        {
            if (GameStart)
            {
                switch (Tags1Activated)
                {
                    case true:
                        {
                            if (pictureBox1.Left <= -1)
                                pictureBox1.Left += TagsMove;
                            break;
                        }
                    case false:
                        {
                            if (pictureBox1.Left >= -42)
                                pictureBox1.Left -= TagsMove;
                            break;
                        }
                }
                switch (Tags2Activated)
                {
                    case true:
                        {
                            if (pictureBox2.Left <= -1)
                                pictureBox2.Left += TagsMove;
                            break;
                        }
                    case false:
                        {
                            if (pictureBox2.Left >= -42)
                                pictureBox2.Left -= TagsMove;
                            break;
                        }
                }
                switch (Tags3Activated)
                {
                    case true:
                        {
                            if (pictureBox3.Left <= -1)
                                pictureBox3.Left += TagsMove;
                            break;
                        }
                    case false:
                        {
                            if (pictureBox3.Left >= -42)
                                pictureBox3.Left -= TagsMove;
                            break;
                        }
                }
                switch (Tags4Activated)
                {
                    case true:
                        {
                            if (pictureBox4.Left <= -1)
                                pictureBox4.Left += TagsMove;
                            break;
                        }
                    case false:
                        {
                            if (pictureBox4.Left >= -42)
                                pictureBox4.Left -= TagsMove;
                            break;
                        }
                }
            }
            if (pictureBox1.Left < -42 && pictureBox2.Left < -42 && pictureBox3.Left < -42 && pictureBox4.Left < -42)
            {
                TagsTimer1.Enabled = false;
            }
        }
        //--------------------------------------------------------------------

        private void Form1_Load(object sender, EventArgs e)
        {
            groupBox1.BackgroundImage = Image.FromFile("Wall.png");
            MainIndex.Image = Image.FromFile("BattleField" + Buffer + ".png");
            pictureBox8.Image = Image.FromFile("Start.png");
            pictureBox9.Image = Image.FromFile("TypeMe.png");
            pictureBox11.Image = Image.FromFile("TypingCastle.png");
            pictureBox12.Image = Image.FromFile("Castle.png");
            pictureBox13.Image = Image.FromFile("ByMajjor0.png");

            pictureBox10.Controls.Add(pictureBox8);
            pictureBox10.Controls.Add(pictureBox9);
            MainIndex.Controls.Add(pictureBox10);
            MainIndex.Controls.Add(pictureBox11);
            MainIndex.Controls.Add(pictureBox12);

            pictureBox8.BackColor = Color.Transparent;
            pictureBox9.BackColor = Color.Transparent;
            pictureBox10.BackColor = Color.Transparent;
            pictureBox11.BackColor = Color.Transparent;
            pictureBox12.BackColor = Color.Transparent;
            pictureBox8.Top = 90;
            pictureBox8.Left = 0;
            pictureBox9.Top = 0;
            pictureBox9.Left = 70;
            pictureBox12.Top = 100;
        }


        //--------------------------------------------------------------------

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            Tags1Activated = true;
            TagsTimer1.Enabled = true;
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            Tags1Activated = false;
        }

        //--------------------------------------------------------------------


        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            Tags2Activated = true;
            TagsTimer1.Enabled = true;
        }
        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            Tags2Activated = false;
        }

        //--------------------------------------------------------------------


        private void pictureBox3_MouseHover(object sender, EventArgs e)
        {
            Tags3Activated = true;
            TagsTimer1.Enabled = true;
        }
        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            Tags3Activated = false;
        }

        //--------------------------------------------------------------------


        private void pictureBox4_MouseHover(object sender, EventArgs e)
        {
            Tags4Activated = true;
            TagsTimer1.Enabled = true;
        }
        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            Tags4Activated = false;
        }
    }
}
