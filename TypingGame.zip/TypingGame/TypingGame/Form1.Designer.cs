﻿namespace TypingGame
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.MainIndex = new System.Windows.Forms.PictureBox();
            this.TagsTimer1 = new System.Windows.Forms.Timer(this.components);
            this.MainIndexMove1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.OneSec = new System.Windows.Forms.Timer(this.components);
            this.One20Sec = new System.Windows.Forms.Timer(this.components);
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.Display1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.L0 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.L1 = new System.Windows.Forms.Label();
            this.L2 = new System.Windows.Forms.Label();
            this.L3 = new System.Windows.Forms.Label();
            this.One2Sec = new System.Windows.Forms.Timer(this.components);
            this.Left1 = new System.Windows.Forms.PictureBox();
            this.One3Sec = new System.Windows.Forms.Timer(this.components);
            this.LeftCannon = new System.Windows.Forms.PictureBox();
            this.LeftCannon2 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.LeftCannon3 = new System.Windows.Forms.PictureBox();
            this.LeftCannon4 = new System.Windows.Forms.PictureBox();
            this.LeftArchorTower = new System.Windows.Forms.PictureBox();
            this.LeftArchorTower3 = new System.Windows.Forms.PictureBox();
            this.LeftArchorTower2 = new System.Windows.Forms.PictureBox();
            this.LeftArchorTower1 = new System.Windows.Forms.PictureBox();
            this.DoubleMoney = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Display1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Left1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftCannon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftCannon2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftCannon3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftCannon4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArchorTower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArchorTower3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArchorTower2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArchorTower1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DoubleMoney)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.Color.Sienna;
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(16, 494);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBox1.Location = new System.Drawing.Point(-60, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 56);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseLeave += new System.EventHandler(this.pictureBox1_MouseLeave);
            this.pictureBox1.MouseHover += new System.EventHandler(this.pictureBox1_MouseHover);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.pictureBox2.Location = new System.Drawing.Point(-60, 86);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(76, 56);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            this.pictureBox2.MouseLeave += new System.EventHandler(this.pictureBox2_MouseLeave);
            this.pictureBox2.MouseHover += new System.EventHandler(this.pictureBox2_MouseHover);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Aqua;
            this.pictureBox3.Location = new System.Drawing.Point(-60, 148);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(76, 56);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            this.pictureBox3.MouseLeave += new System.EventHandler(this.pictureBox3_MouseLeave);
            this.pictureBox3.MouseHover += new System.EventHandler(this.pictureBox3_MouseHover);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Coral;
            this.pictureBox4.Location = new System.Drawing.Point(-60, 210);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(76, 56);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            this.pictureBox4.MouseLeave += new System.EventHandler(this.pictureBox4_MouseLeave);
            this.pictureBox4.MouseHover += new System.EventHandler(this.pictureBox4_MouseHover);
            // 
            // MainIndex
            // 
            this.MainIndex.Location = new System.Drawing.Point(0, 0);
            this.MainIndex.Name = "MainIndex";
            this.MainIndex.Size = new System.Drawing.Size(1600, 541);
            this.MainIndex.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.MainIndex.TabIndex = 5;
            this.MainIndex.TabStop = false;
            this.MainIndex.MouseLeave += new System.EventHandler(this.MainIndex_MouseLeave);
            this.MainIndex.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainIndex_MouseMove);
            // 
            // TagsTimer1
            // 
            this.TagsTimer1.Interval = 10;
            this.TagsTimer1.Tick += new System.EventHandler(this.TagsTimer1_Tick);
            // 
            // MainIndexMove1
            // 
            this.MainIndexMove1.Interval = 10;
            this.MainIndexMove1.Tick += new System.EventHandler(this.MainIndexMove1_Tick);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(1238, 87);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(66, 67);
            this.pictureBox5.TabIndex = 11;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(1204, 254);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(66, 67);
            this.pictureBox6.TabIndex = 12;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(1166, 135);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(66, 67);
            this.pictureBox7.TabIndex = 13;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(1234, 360);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(365, 193);
            this.pictureBox8.TabIndex = 14;
            this.pictureBox8.TabStop = false;
            // 
            // OneSec
            // 
            this.OneSec.Enabled = true;
            this.OneSec.Interval = 1000;
            this.OneSec.Tick += new System.EventHandler(this.OneSec_Tick);
            // 
            // One20Sec
            // 
            this.One20Sec.Enabled = true;
            this.One20Sec.Interval = 50;
            this.One20Sec.Tick += new System.EventHandler(this.One20Sec_Tick);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Location = new System.Drawing.Point(1406, 360);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(193, 121);
            this.pictureBox9.TabIndex = 15;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Location = new System.Drawing.Point(469, 267);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(365, 193);
            this.pictureBox10.TabIndex = 16;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Location = new System.Drawing.Point(351, 0);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(617, 273);
            this.pictureBox11.TabIndex = 17;
            this.pictureBox11.TabStop = false;
            // 
            // Display1
            // 
            this.Display1.BackColor = System.Drawing.Color.MediumPurple;
            this.Display1.Location = new System.Drawing.Point(21, 85);
            this.Display1.Name = "Display1";
            this.Display1.Size = new System.Drawing.Size(209, 541);
            this.Display1.TabIndex = 7;
            this.Display1.TabStop = false;
            this.Display1.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Location = new System.Drawing.Point(25, 86);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(206, 450);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Visible = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Location = new System.Drawing.Point(0, -5);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(1156, 541);
            this.pictureBox13.TabIndex = 20;
            this.pictureBox13.TabStop = false;
            // 
            // L0
            // 
            this.L0.AutoSize = true;
            this.L0.Font = new System.Drawing.Font("微軟正黑體 Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.L0.Location = new System.Drawing.Point(1500, 162);
            this.L0.Name = "L0";
            this.L0.Size = new System.Drawing.Size(62, 25);
            this.L0.TabIndex = 21;
            this.L0.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Javanese Text", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(129, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 64);
            this.label2.TabIndex = 22;
            this.label2.Text = "label2";
            this.label2.Visible = false;
            // 
            // L1
            // 
            this.L1.AutoSize = true;
            this.L1.Font = new System.Drawing.Font("微軟正黑體 Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.L1.Location = new System.Drawing.Point(1516, 199);
            this.L1.Name = "L1";
            this.L1.Size = new System.Drawing.Size(65, 25);
            this.L1.TabIndex = 23;
            this.L1.Text = "label3";
            // 
            // L2
            // 
            this.L2.AutoSize = true;
            this.L2.Font = new System.Drawing.Font("微軟正黑體 Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.L2.Location = new System.Drawing.Point(1515, 241);
            this.L2.Name = "L2";
            this.L2.Size = new System.Drawing.Size(66, 25);
            this.L2.TabIndex = 24;
            this.L2.Text = "label4";
            // 
            // L3
            // 
            this.L3.AutoSize = true;
            this.L3.Font = new System.Drawing.Font("微軟正黑體 Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.L3.Location = new System.Drawing.Point(1516, 276);
            this.L3.Name = "L3";
            this.L3.Size = new System.Drawing.Size(65, 25);
            this.L3.TabIndex = 25;
            this.L3.Text = "label5";
            // 
            // One2Sec
            // 
            this.One2Sec.Interval = 500;
            this.One2Sec.Tick += new System.EventHandler(this.One2Sec_Tick);
            // 
            // Left1
            // 
            this.Left1.Location = new System.Drawing.Point(1727, 0);
            this.Left1.Name = "Left1";
            this.Left1.Size = new System.Drawing.Size(100, 161);
            this.Left1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Left1.TabIndex = 27;
            this.Left1.TabStop = false;
            this.Left1.Click += new System.EventHandler(this.Left1_Click);
            // 
            // One3Sec
            // 
            this.One3Sec.Interval = 300;
            this.One3Sec.Tick += new System.EventHandler(this.One3Sec_Tick);
            // 
            // LeftCannon
            // 
            this.LeftCannon.Location = new System.Drawing.Point(1606, 267);
            this.LeftCannon.Name = "LeftCannon";
            this.LeftCannon.Size = new System.Drawing.Size(171, 159);
            this.LeftCannon.TabIndex = 28;
            this.LeftCannon.TabStop = false;
            this.LeftCannon.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LeftCannon_MouseDown);
            this.LeftCannon.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LeftCannon_MouseMove);
            this.LeftCannon.MouseUp += new System.Windows.Forms.MouseEventHandler(this.LeftCannon_MouseUp);
            // 
            // LeftCannon2
            // 
            this.LeftCannon2.Location = new System.Drawing.Point(1625, 333);
            this.LeftCannon2.Name = "LeftCannon2";
            this.LeftCannon2.Size = new System.Drawing.Size(70, 68);
            this.LeftCannon2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LeftCannon2.TabIndex = 29;
            this.LeftCannon2.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Location = new System.Drawing.Point(1606, 457);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(398, 396);
            this.pictureBox12.TabIndex = 18;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.MouseHover += new System.EventHandler(this.pictureBox12_MouseHover);
            // 
            // LeftCannon3
            // 
            this.LeftCannon3.Location = new System.Drawing.Point(1648, 322);
            this.LeftCannon3.Name = "LeftCannon3";
            this.LeftCannon3.Size = new System.Drawing.Size(70, 68);
            this.LeftCannon3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LeftCannon3.TabIndex = 30;
            this.LeftCannon3.TabStop = false;
            // 
            // LeftCannon4
            // 
            this.LeftCannon4.Location = new System.Drawing.Point(1676, 305);
            this.LeftCannon4.Name = "LeftCannon4";
            this.LeftCannon4.Size = new System.Drawing.Size(70, 68);
            this.LeftCannon4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LeftCannon4.TabIndex = 31;
            this.LeftCannon4.TabStop = false;
            // 
            // LeftArchorTower
            // 
            this.LeftArchorTower.Location = new System.Drawing.Point(1606, 102);
            this.LeftArchorTower.Name = "LeftArchorTower";
            this.LeftArchorTower.Size = new System.Drawing.Size(171, 159);
            this.LeftArchorTower.TabIndex = 32;
            this.LeftArchorTower.TabStop = false;
            this.LeftArchorTower.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LeftArchorTower_MouseDown);
            this.LeftArchorTower.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LeftArchorTower_MouseMove);
            this.LeftArchorTower.MouseUp += new System.Windows.Forms.MouseEventHandler(this.LeftArchorTower_MouseUp);
            // 
            // LeftArchorTower3
            // 
            this.LeftArchorTower3.Location = new System.Drawing.Point(1676, 113);
            this.LeftArchorTower3.Name = "LeftArchorTower3";
            this.LeftArchorTower3.Size = new System.Drawing.Size(70, 91);
            this.LeftArchorTower3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LeftArchorTower3.TabIndex = 35;
            this.LeftArchorTower3.TabStop = false;
            // 
            // LeftArchorTower2
            // 
            this.LeftArchorTower2.Location = new System.Drawing.Point(1648, 130);
            this.LeftArchorTower2.Name = "LeftArchorTower2";
            this.LeftArchorTower2.Size = new System.Drawing.Size(70, 91);
            this.LeftArchorTower2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LeftArchorTower2.TabIndex = 34;
            this.LeftArchorTower2.TabStop = false;
            // 
            // LeftArchorTower1
            // 
            this.LeftArchorTower1.Location = new System.Drawing.Point(1625, 141);
            this.LeftArchorTower1.Name = "LeftArchorTower1";
            this.LeftArchorTower1.Size = new System.Drawing.Size(70, 91);
            this.LeftArchorTower1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LeftArchorTower1.TabIndex = 33;
            this.LeftArchorTower1.TabStop = false;
            // 
            // DoubleMoney
            // 
            this.DoubleMoney.Location = new System.Drawing.Point(573, 584);
            this.DoubleMoney.Name = "DoubleMoney";
            this.DoubleMoney.Size = new System.Drawing.Size(171, 159);
            this.DoubleMoney.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DoubleMoney.TabIndex = 36;
            this.DoubleMoney.TabStop = false;
            this.DoubleMoney.Click += new System.EventHandler(this.DoubleMoney_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox1.Location = new System.Drawing.Point(559, 86);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(241, 43);
            this.textBox1.TabIndex = 37;
            this.textBox1.Text = "Name";
            this.textBox1.Visible = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(559, 135);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 47);
            this.button1.TabIndex = 38;
            this.button1.Text = "Enter";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox2.Location = new System.Drawing.Point(806, 12);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(317, 470);
            this.textBox2.TabIndex = 39;
            this.textBox2.Visible = false;
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(698, 135);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 47);
            this.button2.TabIndex = 40;
            this.button2.Text = "Again";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.pictureBox14.Location = new System.Drawing.Point(2, 438);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(76, 56);
            this.pictureBox14.TabIndex = 41;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Visible = false;
            this.pictureBox14.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pictureBox15.Location = new System.Drawing.Point(2, 385);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(47, 47);
            this.pictureBox15.TabIndex = 42;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Visible = false;
            this.pictureBox15.Click += new System.EventHandler(this.pictureBox15_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1152, 494);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.DoubleMoney);
            this.Controls.Add(this.LeftArchorTower3);
            this.Controls.Add(this.LeftArchorTower2);
            this.Controls.Add(this.LeftArchorTower1);
            this.Controls.Add(this.LeftArchorTower);
            this.Controls.Add(this.LeftCannon4);
            this.Controls.Add(this.LeftCannon3);
            this.Controls.Add(this.LeftCannon2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.LeftCannon);
            this.Controls.Add(this.Display1);
            this.Controls.Add(this.Left1);
            this.Controls.Add(this.L3);
            this.Controls.Add(this.L2);
            this.Controls.Add(this.L1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.L0);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.MainIndex);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Display1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Left1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftCannon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftCannon2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftCannon3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftCannon4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArchorTower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArchorTower3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArchorTower2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftArchorTower1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DoubleMoney)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox MainIndex;
        private System.Windows.Forms.Timer TagsTimer1;
        private System.Windows.Forms.Timer MainIndexMove1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Timer OneSec;
        private System.Windows.Forms.Timer One20Sec;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox Display1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label L0;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label L1;
        private System.Windows.Forms.Label L2;
        private System.Windows.Forms.Label L3;
        private System.Windows.Forms.Timer One2Sec;
        private System.Windows.Forms.PictureBox Left1;
        private System.Windows.Forms.Timer One3Sec;
        private System.Windows.Forms.PictureBox LeftCannon;
        private System.Windows.Forms.PictureBox LeftCannon2;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox LeftCannon3;
        private System.Windows.Forms.PictureBox LeftCannon4;
        private System.Windows.Forms.PictureBox LeftArchorTower;
        private System.Windows.Forms.PictureBox LeftArchorTower3;
        private System.Windows.Forms.PictureBox LeftArchorTower2;
        private System.Windows.Forms.PictureBox LeftArchorTower1;
        private System.Windows.Forms.PictureBox DoubleMoney;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
    }
}

